2d Backgrounds for platformer game. Dungeons and Cave, Parallax vector illustration.
By Creative Game Assets
https://opengameart.org/content/2d-backgrounds-for-platformer-game-dungeons-and-cave-parallax-vector-illustration

______________________
\ LICENSE INFO
 ---------------------

These assets are released under a CREATIVE COMMONS ATTRIBUTION-SHAREALIKE 4.0 INTERNATIONAL
license. See LICENSE_cc4-by-sa.txt for the full text of the license.

You are permitted to utilize these assets in commercial releases.

You MUST include the FOLLOWING CREDIT in YOUR MEDIA (game, video, etc.):

  Contains assets ©2018 Creative Game Assets (https://opengameart.org/users/creativegameassetscom)
  Licensed under Creative Commons Attribution-ShareAlike 4.0 International

Any unauthorized use (i.e. without the above credit) presents as copyright
infringement and is strictly illegal.
