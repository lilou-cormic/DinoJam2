Free Music Pack 4: Electronic 2
By Joshua McLean

______________________
\ LICENSE INFO
 ---------------------

These tracks are released under a CREATIVE COMMONS ATTRIBUTION 4.0 INTERNATIONAL
license. See LICENSE.txt for the full text of the license.

You are permitted to utilize these tracks in commercial releases.

You MUST include the FOLLOWING CREDIT in YOUR MEDIA (game, video, etc.):

  Contains music ©2020 Joshua McLean (https://joshua-mclean.itch.io)
  Licensed under Creative Commons Attribution 4.0 International

Any unauthorized use (i.e. without the above credit) presents as copyright
infringement and is strictly illegal.

______________________
\ INCLUDED TRACKS
 ---------------------

Behemoth / 4-4 intense digirock / boss
130bpm / loop 0:14.76

Infernal Heat / 4-4 electro beat / lava world or intense race

Return of Club / 4-4 EDM / club scene or techy battle
133bpm / loop 0:28.87

Sea Drive / 4-4 poppy dance / a pleasant drive or scene
136bpm / loop at start

Tech Space / 4-4 electronica / a driven level or race
140bpm / loop at start

Voltaic Gales / 4-4 ambient but intense / level or scene
150bpm / loop 0:12.80

______________________
\ MORE MUSIC
 ---------------------

If you use the music, please support me!
Support on Patreon: https://www.patreon.com/JoshuaMcLean
Buy music on Bandcamp: https://joshuamclean.bandcamp.com/

Please mention @MrJoshuaMcLean with your project if you're on Twitter
https://twitter.com/MrJoshuaMcLean

For more FREE music, visit
https://joshua-mclean.itch.io/

To contact for commissions (original music)
Email / joshua.mclean@8bitstoinfinty.com
Twitter / @mrjoshuamclean
